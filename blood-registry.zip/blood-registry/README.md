# 🩸 Blood Donor Registry

A full-stack web application to register and manage blood donors, built with **Node.js + Express + MySQL (AWS RDS)**.

---

## 📁 Project Structure

```
blood-registry/
├── server.js              # Express server entry point
├── package.json
├── .env.example           # Rename to .env and fill in your RDS details
├── config/
│   └── db.js              # MySQL connection pool + table init
├── routes/
│   └── members.js         # REST API: GET / POST / DELETE
└── public/
    └── index.html         # Frontend (HTML + CSS + JS)
```

---

## 🚀 AWS Deployment Guide

### 1. Create an RDS MySQL Instance

1. Go to **AWS Console → RDS → Create database**
2. Engine: **MySQL 8.x**
3. Template: Free tier (or your preference)
4. Set **DB identifier**, **Master username**, and **Master password**
5. Under **Connectivity**, allow access from your EC2 security group
6. Note the **Endpoint** (looks like `xxx.rds.amazonaws.com`)

### 2. Launch an EC2 Instance

1. Go to **AWS Console → EC2 → Launch Instance**
2. Choose **Amazon Linux 2023** or **Ubuntu 22.04**
3. Instance type: `t2.micro` (free tier) or higher
4. Security group: open **port 3000** (or 80 if using a reverse proxy)
5. Connect via SSH

### 3. Install Node.js on EC2

```bash
# Amazon Linux 2023
sudo dnf install -y nodejs npm

# Ubuntu
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs
```

### 4. Deploy the App

```bash
# Upload files (from your local machine)
scp -i your-key.pem -r blood-registry/ ec2-user@your-ec2-ip:~/

# On EC2
cd ~/blood-registry
npm install

# Create .env from example
cp .env.example .env
nano .env   # Fill in your RDS details
```

### 5. Configure `.env`

```env
DB_HOST=your-rds-endpoint.rds.amazonaws.com
DB_PORT=3306
DB_USER=admin
DB_PASSWORD=your_password
DB_NAME=blood_registry
PORT=3000
NODE_ENV=production
```

### 6. Run the App

```bash
# Run directly
node server.js

# Or keep it running with PM2 (recommended)
npm install -g pm2
pm2 start server.js --name blood-registry
pm2 save
pm2 startup
```

### 7. (Optional) Run on Port 80 with Nginx

```bash
sudo apt install nginx -y

# /etc/nginx/sites-available/blood-registry
server {
    listen 80;
    server_name your-domain-or-ec2-ip;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

```bash
sudo ln -s /etc/nginx/sites-available/blood-registry /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl restart nginx
```

---

## 🔌 API Reference

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/api/members` | Fetch all donors |
| `POST` | `/api/members` | Add a new donor |
| `DELETE` | `/api/members/:id` | Remove a donor |
| `GET` | `/health` | Health check (for ELB) |

### POST `/api/members` — Request Body

```json
{
  "name": "Arjun Menon",
  "phone": "+91 98765 43210",
  "blood_group": "O+",
  "place": "Thrissur, Kerala"
}
```

---

## 🛡️ Security Notes

- **Never commit `.env`** to version control — it's in `.gitignore`
- RDS security group should only allow inbound on port **3306** from your EC2 security group
- Use **SSL** for RDS connections in production (already configured in `db.js`)
- Consider adding an **Application Load Balancer** + **HTTPS** (ACM certificate) for production

---

## 🗃️ Database Schema

```sql
CREATE TABLE members (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  name        VARCHAR(100)  NOT NULL,
  phone       VARCHAR(20)   NOT NULL,
  blood_group VARCHAR(5)    NOT NULL,
  place       VARCHAR(100)  NOT NULL,
  created_at  TIMESTAMP     DEFAULT CURRENT_TIMESTAMP
);
```

The table is **auto-created** on first run — no manual SQL needed.
