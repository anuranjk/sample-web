const express = require('express');
const router  = express.Router();
const { pool } = require('../config/db');

// ── POST /api/members  ── Add a new member ──────────────────────────────────
router.post('/', async (req, res) => {
  const { name, phone, blood_group, place } = req.body;

  if (!name || !phone || !blood_group || !place) {
    return res.status(400).json({ error: 'All fields are required.' });
  }

  try {
    const [result] = await pool.execute(
      'INSERT INTO members (name, phone, blood_group, place) VALUES (?, ?, ?, ?)',
      [name.trim(), phone.trim(), blood_group.trim(), place.trim()]
    );
    res.status(201).json({
      message: 'Member added successfully!',
      id: result.insertId
    });
  } catch (err) {
    console.error('DB insert error:', err);
    res.status(500).json({ error: 'Database error. Please try again.' });
  }
});

// ── GET /api/members  ── Fetch all members ──────────────────────────────────
router.get('/', async (req, res) => {
  try {
    const [rows] = await pool.execute(
      'SELECT * FROM members ORDER BY created_at DESC'
    );
    res.json(rows);
  } catch (err) {
    console.error('DB fetch error:', err);
    res.status(500).json({ error: 'Database error. Please try again.' });
  }
});

// ── DELETE /api/members/:id  ── Remove a member ─────────────────────────────
router.delete('/:id', async (req, res) => {
  try {
    await pool.execute('DELETE FROM members WHERE id = ?', [req.params.id]);
    res.json({ message: 'Member removed.' });
  } catch (err) {
    console.error('DB delete error:', err);
    res.status(500).json({ error: 'Database error. Please try again.' });
  }
});

module.exports = router;
